#include "common.h"
#include "zip.h"
#include <stdio.h>
#include <fcntl.h>

char buffer[BUF_SIZE];

zip_time_t get_zip_time(uint16_t raw_time) {
    zip_time_t zt;
    zt.seconds = SECONDS(raw_time);
    zt.minutes = MINUTES(raw_time);
    zt.hours = HOURS(raw_time);
    return zt;
}

zip_date_t get_zip_date(uint16_t raw_date) {
    zip_date_t zd;
    zd.day = DAY(raw_date);
    zd.month = MONTH(raw_date);
    zd.year = YEAR(raw_date);
    return zd;
}

void print_file_info(cfh_t header) {
    zip_time_t zt = get_zip_time(header.modification_time);
    zip_date_t zd = get_zip_date(header.modification_date);
    printf("*************************************************\n");
    printf("Версия: %x\n", header.version);
    printf("Флаги: %x\n", header.flags);
    printf("Метод сжатия: %x\n", header.compression);
    printf("Время модифиекации: %2u:%2u:%2u\n", zt.hours, zt.minutes, zt.seconds);
    printf("Дата модифиекации: %2u.%2u.%4u\n", zd.day, zd.month, zd.year);
    printf("CRC: %x\n", header.crc);
    printf("Сжатый размер: %x\n", header.compressed_size);
    printf("Несжатый размер: %x\n", header.uncompressed_size);
    printf("Длина имени файла: %x\n", header.filename_len);
    printf("Дополнительная длина поля: %x\n", header.extrafield_len);
    printf("*************************************************\n");
}

int zip_contains(char* filename) {
    
    uint32_t sig;
    cfh_t zh;
    int result = -1;

    int fd = open(filename, O_RDONLY);
    if (fd == -1)
        err_sys("Ошибка открытия файла: %s", filename);

    while( read(fd, &sig, sizeof(uint32_t)) == sizeof(uint32_t)) {
        if (sig == FILE_HEADER_SIG) {
            /*printf("sig = %x\n", sig);
            result = 1;
            break;*/
            if (read(fd, &zh, sizeof(cfh_t)) == sizeof(cfh_t)) {
                read(fd, &buffer, sizeof(char) * zh.filename_len);
                buffer[zh.filename_len] = '\0';
                if (zh.external_attr & 0x10)
                    printf("Имя файла: %s, это каталог\n", buffer);
                else    
                    //printf("Имя файла: %s, длина имени файла: %u, внешний атрибут: %x\n", 
                    //        buffer, zh.filename_len,  zh.external_attr);
                    print_file_info(zh);        
            }
        }
        else {
            lseek(fd, -(sizeof(uint32_t) - sizeof(uint8_t)), SEEK_CUR);
        }
    }
    close(fd);
    return result;
}
